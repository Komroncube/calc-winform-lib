﻿namespace calc_winform
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            button20 = new Button();
            textBox1 = new TextBox();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(3, 517);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(123, 90);
            button1.TabIndex = 0;
            button1.Text = "+/-";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(133, 517);
            button2.Margin = new Padding(3, 4, 3, 4);
            button2.Name = "button2";
            button2.Size = new Size(123, 90);
            button2.TabIndex = 1;
            button2.Text = "0";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button16_Click;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button3.Location = new Point(263, 517);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(123, 90);
            button3.TabIndex = 2;
            button3.Text = ",";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button4.Location = new Point(393, 517);
            button4.Margin = new Padding(3, 4, 3, 4);
            button4.Name = "button4";
            button4.Size = new Size(123, 90);
            button4.TabIndex = 3;
            button4.Text = "=";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button5.Location = new Point(393, 420);
            button5.Margin = new Padding(3, 4, 3, 4);
            button5.Name = "button5";
            button5.Size = new Size(123, 90);
            button5.TabIndex = 7;
            button5.Text = "+";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button18_Click;
            // 
            // button6
            // 
            button6.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button6.Location = new Point(263, 420);
            button6.Margin = new Padding(3, 4, 3, 4);
            button6.Name = "button6";
            button6.Size = new Size(123, 90);
            button6.TabIndex = 6;
            button6.Text = "3";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button16_Click;
            // 
            // button7
            // 
            button7.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button7.Location = new Point(133, 420);
            button7.Margin = new Padding(3, 4, 3, 4);
            button7.Name = "button7";
            button7.Size = new Size(123, 90);
            button7.TabIndex = 5;
            button7.Text = "2";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button16_Click;
            // 
            // button8
            // 
            button8.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button8.Location = new Point(3, 420);
            button8.Margin = new Padding(3, 4, 3, 4);
            button8.Name = "button8";
            button8.Size = new Size(123, 90);
            button8.TabIndex = 4;
            button8.Text = "1";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button16_Click;
            // 
            // button9
            // 
            button9.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button9.Location = new Point(393, 323);
            button9.Margin = new Padding(3, 4, 3, 4);
            button9.Name = "button9";
            button9.Size = new Size(123, 90);
            button9.TabIndex = 11;
            button9.Text = "-";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button18_Click;
            // 
            // button10
            // 
            button10.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button10.Location = new Point(263, 323);
            button10.Margin = new Padding(3, 4, 3, 4);
            button10.Name = "button10";
            button10.Size = new Size(123, 90);
            button10.TabIndex = 10;
            button10.Text = "6";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button16_Click;
            // 
            // button11
            // 
            button11.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button11.Location = new Point(133, 323);
            button11.Margin = new Padding(3, 4, 3, 4);
            button11.Name = "button11";
            button11.Size = new Size(123, 90);
            button11.TabIndex = 9;
            button11.Text = "5";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button16_Click;
            // 
            // button12
            // 
            button12.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button12.Location = new Point(3, 323);
            button12.Margin = new Padding(3, 4, 3, 4);
            button12.Name = "button12";
            button12.Size = new Size(123, 90);
            button12.TabIndex = 8;
            button12.Text = "4";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button16_Click;
            // 
            // button13
            // 
            button13.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button13.Location = new Point(393, 229);
            button13.Margin = new Padding(3, 4, 3, 4);
            button13.Name = "button13";
            button13.Size = new Size(123, 90);
            button13.TabIndex = 15;
            button13.Text = "*";
            button13.UseVisualStyleBackColor = true;
            button13.Click += button18_Click;
            // 
            // button14
            // 
            button14.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button14.Location = new Point(264, 229);
            button14.Margin = new Padding(3, 4, 3, 4);
            button14.Name = "button14";
            button14.Size = new Size(123, 90);
            button14.TabIndex = 14;
            button14.Text = "9";
            button14.UseVisualStyleBackColor = true;
            button14.Click += button16_Click;
            // 
            // button15
            // 
            button15.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button15.Location = new Point(134, 229);
            button15.Margin = new Padding(3, 4, 3, 4);
            button15.Name = "button15";
            button15.Size = new Size(123, 90);
            button15.TabIndex = 13;
            button15.Text = "8";
            button15.UseVisualStyleBackColor = true;
            button15.Click += button16_Click;
            // 
            // button16
            // 
            button16.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button16.Location = new Point(4, 229);
            button16.Margin = new Padding(3, 4, 3, 4);
            button16.Name = "button16";
            button16.Size = new Size(123, 90);
            button16.TabIndex = 12;
            button16.Text = "7";
            button16.UseVisualStyleBackColor = true;
            button16.Click += button16_Click;
            // 
            // button17
            // 
            button17.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button17.Location = new Point(393, 131);
            button17.Margin = new Padding(3, 4, 3, 4);
            button17.Name = "button17";
            button17.Size = new Size(123, 90);
            button17.TabIndex = 19;
            button17.Text = "/";
            button17.UseVisualStyleBackColor = true;
            button17.Click += button18_Click;
            // 
            // button18
            // 
            button18.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button18.Location = new Point(264, 131);
            button18.Margin = new Padding(3, 4, 3, 4);
            button18.Name = "button18";
            button18.Size = new Size(123, 90);
            button18.TabIndex = 18;
            button18.Text = "%";
            button18.UseVisualStyleBackColor = true;
            button18.Click += button18_Click;
            // 
            // button19
            // 
            button19.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button19.Location = new Point(134, 131);
            button19.Margin = new Padding(3, 4, 3, 4);
            button19.Name = "button19";
            button19.Size = new Size(123, 90);
            button19.TabIndex = 17;
            button19.Text = "del";
            button19.UseVisualStyleBackColor = true;
            button19.Click += button19_Click;
            // 
            // button20
            // 
            button20.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button20.Location = new Point(4, 131);
            button20.Margin = new Padding(3, 4, 3, 4);
            button20.Name = "button20";
            button20.Size = new Size(123, 90);
            button20.TabIndex = 16;
            button20.Text = "C";
            button20.UseVisualStyleBackColor = true;
            button20.Click += button20_Click;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 35F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.Location = new Point(12, 23);
            textBox1.MaxLength = 20;
            textBox1.Name = "textBox1";
            textBox1.ReadOnly = true;
            textBox1.Size = new Size(502, 101);
            textBox1.TabIndex = 20;
            textBox1.Text = "0";
            textBox1.TextAlign = HorizontalAlignment.Right;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(11F, 28F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(521, 610);
            Controls.Add(textBox1);
            Controls.Add(button17);
            Controls.Add(button18);
            Controls.Add(button19);
            Controls.Add(button20);
            Controls.Add(button13);
            Controls.Add(button14);
            Controls.Add(button15);
            Controls.Add(button16);
            Controls.Add(button9);
            Controls.Add(button10);
            Controls.Add(button11);
            Controls.Add(button12);
            Controls.Add(button5);
            Controls.Add(button6);
            Controls.Add(button7);
            Controls.Add(button8);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Calculator";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button19;
        private Button button20;
        private TextBox textBox1;
    }
}